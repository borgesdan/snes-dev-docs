This is a W65C816S (65816) syntax file for Notepad++.
It includes the full instruction set for both the W65C816S
and SPC700 processors, as well as WLA's commands for them.
To install, open Notepad++ and go to:

- "Language" -> "Define your language..." -> "Import" -> "W65C816S.xml"

Then select "W65C816S Assembly" under "Language".
